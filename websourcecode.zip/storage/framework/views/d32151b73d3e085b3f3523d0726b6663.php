

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('public.posts.search', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
            $key = 'posts_' . $category->slug;
        ?>

        <?php if(!empty($posts[$key]) && $posts[$key]->count()): ?>
            <div class="py-2 mt-2">
                <h5 class="fw-bold text-uppercase text-dark"><?php echo e($category->name); ?></h5>
            </div>

            <div class="row g-3">
                <?php $__currentLoopData = $posts[$key]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo $__env->make('public._card', ['post' => $post], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <div class="text-center mt-2">
                <a href="<?php echo e(route('posts.kategori', $category->slug)); ?>"
                    class="btn btn-sm btn-outline-secondary rounded-pill px-4">
                    <i class="fas fa-arrow-right me-1"></i> Lihat Semua <?php echo e($category->name); ?>

                </a>
            </div>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app_public', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH P:\laravel12\websourcecode\resources\views/public/home.blade.php ENDPATH**/ ?>