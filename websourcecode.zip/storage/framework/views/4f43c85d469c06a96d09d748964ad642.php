

<?php $__env->startSection('content'); ?>
    <div class="container py-4">
        
        <div class="mb-1">
            <h4 class="fw-bold"><?php echo e($post->title); ?></h4>
            <div class="text-muted small">
                <i class="fas fa-user"></i> <?php echo e($post->author->name ?? 'Anonim'); ?> |
                <i class="fas fa-calendar-alt"></i> <?php echo e($post->created_at->translatedFormat('d M Y')); ?> |
                <i class="fas fa-folder-open"></i> <?php echo e($post->category->name ?? '-'); ?>

            </div>
            <div class="mt-1">
                <?php $__currentLoopData = $post->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <span class="badge bg-info text-dark"><?php echo e($tag->name); ?></span>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>

        
        <?php if($post->technologies->count()): ?>
            <div class="mb-2 ">
                <div class="d-flex flex-wrap gap-2">
                    <?php $__currentLoopData = $post->technologies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tech): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $key = strtolower(str_replace(['.', ' '], '', $tech->name));
                            $icons = [
                                'codeigniter' => 'devicon-codeigniter-plain colored',
                                'php' => 'devicon-php-plain colored',
                                'html' => 'devicon-html5-plain colored',
                                'css' => 'devicon-css3-plain colored',
                                'vue' => 'devicon-vuejs-plain colored',
                                'vuejs' => 'devicon-vuejs-plain colored',
                                'vue.js' => 'devicon-vuejs-plain colored',
                                'react' => 'devicon-react-original colored',
                                'javascript' => 'devicon-javascript-plain colored',
                                'laravel' => 'devicon-laravel-plain colored',
                            ];
                            $iconClass = $icons[$key] ?? null;
                        ?>

                        <a href="<?php echo e(route('posts.teknologi', \Str::slug($tech->name))); ?>"
                            class="badge d-inline-flex align-items-center gap-1 px-2 py-1 fw-normal text-decoration-none"
                            style="background: #f0f0f0; color: #222; font-size: 0.75rem;">
                            <?php if($iconClass): ?>
                                <i class="<?php echo e($iconClass); ?>" style="font-size: 14px;"></i>
                            <?php else: ?>
                                <i class="fas fa-code text-secondary" style="font-size: 13px;"></i>
                            <?php endif; ?>
                            <?php echo e($tech->name); ?>

                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        <?php endif; ?>




        
        <?php
            $cover = $post->images->where('type', 'cover')->first();
        ?>
        <?php if($cover): ?>
            <div class="mb-3">
                <img src="<?php echo e($cover->url); ?>" class="img-fluid rounded shadow-sm w-100"
                    style="max-height: 300px; object-fit: cover;" alt="cover <?php echo e($post->title); ?>">
            </div>
        <?php endif; ?>

        
        <div class="mb-3 small text-secondary">
            <strong>Deskripsi:</strong>
            <p class="mb-0"><?php echo e($post->description); ?></p>
        </div>

        
        <div class="mb-4">
            <div class="border rounded p-3 bg-light small">
                <?php echo nl2br(e($post->content)); ?>

            </div>
        </div>

        
        <?php if($post->images->where('type', 'internal')->count()): ?>
            <div class="mb-4">
                <strong class="small">Gambar Tambahan:</strong>
                <div class="row g-2 mt-1">
                    <?php $__currentLoopData = $post->images->where('type', 'internal'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-6 col-md-4">
                            <img src="<?php echo e($img->url); ?>" class="img-fluid rounded shadow-sm border" alt="image">
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        <?php endif; ?>

        
        <div class="d-flex gap-2 mb-4">
            <?php if($post->url_download): ?>
                <a href="<?php echo e($post->url_download); ?>" class="btn btn-sm btn-success" target="_blank">
                    <i class="fas fa-download me-1"></i> Download
                </a>
            <?php endif; ?>
            <a href="<?php echo e(route('home')); ?>" class="btn btn-sm btn-secondary">
                <i class="fas fa-arrow-left me-1"></i> Kembali
            </a>
        </div>

        
        <hr>
        <h6 class="fw-semibold mb-3">Komentar</h6>

        
        <?php if(auth()->guard()->check()): ?>
            <form action="<?php echo e(route('comments.store', $post->id)); ?>" method="POST" class="mb-4 comment-form">
                <?php echo csrf_field(); ?>
                <textarea name="content" rows="2" class="form-control <?php $__errorArgs = ['content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                    placeholder="Tulis komentar..."><?php echo e(old('content')); ?></textarea>
                <?php $__errorArgs = ['content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <button class="btn btn-sm btn-primary mt-2"><i class="fas fa-paper-plane me-1"></i> Kirim</button>
            </form>
        <?php else: ?>
            <p class="small text-muted">Silakan <a href="<?php echo e(route('login')); ?>">login</a> untuk memberi komentar.</p>
        <?php endif; ?>

        
        <div id="comments-list">

            <?php $__empty_1 = true; $__currentLoopData = $post->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="mb-3 p-3 rounded border bg-white small">
                    <div class="fw-semibold"><?php echo e($comment->user->name ?? 'Anonim'); ?>

                        <span class="text-muted">• <?php echo e($comment->created_at->diffForHumans()); ?></span>
                    </div>
                    <div class="text-secondary mb-2"><?php echo e($comment->content); ?></div>

                    
                    <?php if($comment->replies->count()): ?>
                        <div class="ms-3 ps-3 border-start">
                            <?php $__currentLoopData = $comment->replies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reply): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="mb-2">
                                    <strong><?php echo e($reply->user->name ?? 'Anonim'); ?></strong>:
                                    <?php echo e($reply->content); ?>

                                    <div class="text-muted small"><?php echo e($reply->created_at->diffForHumans()); ?></div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endif; ?>

                    
                    <?php if(auth()->guard()->check()): ?>
                        <form action="<?php echo e(route('comments.reply', $comment->id)); ?>" method="POST"
                            class="reply-form mt-2 small">
                            <?php echo csrf_field(); ?>
                            <textarea name="content" rows="2" class="form-control form-control-sm mb-2 <?php $__errorArgs = ['content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                placeholder="Balas komentar..."></textarea>
                            <button class="btn btn-sm btn-outline-secondary">
                                <i class="fas fa-reply me-1"></i> Balas
                            </button>
                        </form>
                    <?php endif; ?>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p class="text-muted small">Belum ada komentar.</p>
            <?php endif; ?>
        </div>
    </div>
    <?php $__env->startPush('scripts'); ?>
        <script>
            // Tambah komentar utama
            $(document).on('submit', 'form.comment-form', function(e) {
                e.preventDefault();

                let form = $(this);
                let content = form.find('textarea[name="content"]').val();

                $.post(form.attr('action'), {
                    _token: '<?php echo e(csrf_token()); ?>',
                    content: content
                }, function(res) {
                    if (res.success) {
                        $('#comments-list').prepend(res.comment);
                        form.find('textarea[name="content"]').val('');
                    }
                });
            });

            // Balas komentar
            $(document).on('submit', '.reply-form', function(e) {
                e.preventDefault();

                let form = $(this);
                let content = form.find('textarea[name="content"]').val();
                let action = form.attr('action');

                $.post(action, {
                    _token: '<?php echo e(csrf_token()); ?>',
                    content: content
                }, function(res) {
                    if (res.success) {
                        form.prev('.replies').append(res.reply);
                        form.find('textarea[name="content"]').val('');
                    }
                });
            });
        </script>
    <?php $__env->stopPush(); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app_public', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH P:\laravel12\websourcecode\resources\views/public/posts/show.blade.php ENDPATH**/ ?>