

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h2>Tambah Post</h2>

        <form action="<?php echo e(route('posts.store')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo $__env->make('posts._form', ['submit' => 'Simpan'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.appmaster', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH P:\laravel12\websourcecode\resources\views/posts/create.blade.php ENDPATH**/ ?>