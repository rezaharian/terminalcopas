<div class="mb-3 p-3 rounded border bg-white small">
    <div class="fw-semibold"><?php echo e($comment->user->name ?? 'Anonim'); ?>

        <span class="text-muted">• <?php echo e($comment->created_at->diffForHumans()); ?></span>
    </div>
    <div class="text-secondary mb-2"><?php echo e($comment->content); ?></div>
    <div class="replies ms-3 ps-3 border-start"></div>

    <?php if(auth()->guard()->check()): ?>
        <form action="<?php echo e(route('comments.reply', $comment->id)); ?>" method="POST" class="reply-form mt-2 small">
            <?php echo csrf_field(); ?>
            <textarea name="content" rows="2" class="form-control form-control-sm mb-2" placeholder="Balas komentar..."></textarea>
            <button class="btn btn-sm btn-outline-secondary">
                <i class="fas fa-reply me-1"></i> Balas
            </button>
        </form>
    <?php endif; ?>
</div>
<?php /**PATH P:\laravel12\websourcecode\resources\views/public/posts/_comment.blade.php ENDPATH**/ ?>