

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="d-flex justify-content-between align-items-center mb-2">
            <h4 class="fw-semibold mb-0">Daftar Post</h4>
            <a href="<?php echo e(route('posts.create')); ?>" class="btn btn-sm btn-primary">
                <i class="fas fa-plus me-1"></i> Tambah Post
            </a>
        </div>

        <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible fade show small" role="alert">
                <?php echo e(session('success')); ?>

                <button type="button" class="btn-close btn-sm" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <div class="card shadow-sm">
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-sm table-hover table-bordered align-middle mb-0 small">
                        <thead class="table-light">
                            <tr class="text-center">
                                <th style="width: 30%">Judul</th>
                                <th>Kategori</th>
                                <th>Status</th>
                                <th>Penulis</th>
                                <th style="width: 23%">Opsi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php use Illuminate\Support\Str; ?>

                            <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e(Str::limit($post->title, 28)); ?></td>
                                    <td><?php echo e($post->category->name ?? '-'); ?></td>
                                    <td class="text-center">
                                        <span
                                            class="badge bg-<?php echo e($post->status === 'published' ? 'success' : 'secondary'); ?>">
                                            <?php echo e(ucfirst($post->status)); ?>

                                        </span>
                                    </td>
                                    <td><?php echo e($post->author->name ?? '-'); ?></td>
                                    <td class="text-center">
                                        <div class="d-flex justify-content-center gap-1">
                                            <a href="<?php echo e(route('posts.show', $post->id)); ?>" class="btn btn-sm btn-light"
                                                title="Lihat">
                                                <i class="fas fa-eye text-secondary"></i>
                                            </a>
                                            <a href="<?php echo e(route('posts.edit', $post->id)); ?>" class="btn btn-sm btn-light"
                                                title="Edit">
                                                <i class="fas fa-edit text-warning"></i>
                                            </a>
                                            <form action="<?php echo e(route('posts.destroy', $post->id)); ?>" method="POST"
                                                onsubmit="return confirm('Hapus post ini?')">
                                                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-sm btn-light" title="Hapus">
                                                    <i class="fas fa-trash text-danger"></i>
                                                </button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="5" class="text-center text-muted py-3">Belum ada post.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <div class="mt-3 small">
            <?php echo e($posts->links('pagination::bootstrap-5')); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.appmaster', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH P:\laravel12\websourcecode\resources\views/posts/index.blade.php ENDPATH**/ ?>