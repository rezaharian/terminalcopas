

<?php $__env->startSection('content'); ?>
    <div class="container">
        

        <div class="text-center py-4">
            <h3 class="fw-bold text-uppercase text-dark">
                Kategori: <?php echo e($category->name); ?>

            </h3>
            <p class="text-muted small">Menampilkan semua postingan di kategori ini.</p>
        </div>
        <?php echo $__env->make('public.posts.search', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        
        <?php if($posts->count()): ?>
            <div class="row g-3">
                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo $__env->make('public._card', ['post' => $post], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            
            <div class="d-flex justify-content-center mt-4">
                <?php echo e($posts->links('pagination::bootstrap-5')); ?>

            </div>
        <?php else: ?>
            <div class="text-center text-muted my-5">
                <p>Belum ada post dalam kategori ini.</p>
            </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app_public', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH P:\laravel12\websourcecode\resources\views/public/posts/kategori.blade.php ENDPATH**/ ?>