<div class="mb-2">
    <strong><?php echo e($reply->user->name ?? 'Anonim'); ?></strong>:
    <?php echo e($reply->content); ?>

    <div class="text-muted small"><?php echo e($reply->created_at->diffForHumans()); ?></div>
</div>
<?php /**PATH P:\laravel12\websourcecode\resources\views/public/posts/_reply.blade.php ENDPATH**/ ?>