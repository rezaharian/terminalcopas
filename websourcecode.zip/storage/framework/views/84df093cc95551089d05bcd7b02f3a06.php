<div class="mb-3">
    <label class="form-label">Nama</label>
    <input type="text" name="name" class="form-control" value="<?php echo e(old('name', $user->name ?? '')); ?>" required>
</div>

<div class="mb-3">
    <label class="form-label">Email</label>
    <input type="email" name="email" class="form-control" value="<?php echo e(old('email', $user->email ?? '')); ?>" required>
</div>

<div class="mb-3">
    <label class="form-label">Password <?php echo e(isset($user) ? '(Kosongkan jika tidak diubah)' : ''); ?></label>
    <input type="password" name="password" class="form-control" <?php echo e(isset($user) ? '' : 'required'); ?>>
</div>

<div class="mb-3">
    <label class="form-label">Konfirmasi Password</label>
    <input type="password" name="password_confirmation" class="form-control" <?php echo e(isset($user) ? '' : 'required'); ?>>
</div>

<div class="mb-3">
    <label class="form-label">Role</label>
    <select name="role" class="form-select" required>
        <option value="">-- Pilih Role --</option>
        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($role->name); ?>"
                <?php echo e(old('role', isset($user) && $user->roles->first() ? $user->roles->first()->name : '') == $role->name ? 'selected' : ''); ?>>
                <?php echo e(ucfirst($role->name)); ?>

            </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>
<?php /**PATH P:\laravel12\websourcecode\resources\views/admin/users/form.blade.php ENDPATH**/ ?>