

<?php $__env->startSection('content'); ?>
    <div class="container py-4">
        <h2 class="mb-3">Detail User</h2>

        <ul class="list-group">
            <li class="list-group-item"><strong>Nama:</strong> <?php echo e($user->name); ?></li>
            <li class="list-group-item"><strong>Email:</strong> <?php echo e($user->email); ?></li>
            <li class="list-group-item"><strong>Role:</strong> <?php echo e($user->getRoleNames()->implode(', ')); ?></li>
        </ul>

        <a href="<?php echo e(route('admin.users.index')); ?>" class="btn btn-secondary mt-3">Kembali</a>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.appmaster', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH P:\laravel12\websourcecode\resources\views/admin/users/show.blade.php ENDPATH**/ ?>