<?php $__env->startSection('content'); ?>
    <div class="container ">
        <h4>halo selamat datang cuy</h4>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.appmaster', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH P:\laravel12\websourcecode\resources\views/dashboard.blade.php ENDPATH**/ ?>