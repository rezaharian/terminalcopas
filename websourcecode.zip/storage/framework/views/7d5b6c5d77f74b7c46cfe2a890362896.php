

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h4 class="fw-semibold"><?php echo e($post->title); ?></h4>

        <div class="mb-2 text-muted small">
            Oleh <strong><?php echo e($post->author->name ?? 'Tidak diketahui'); ?></strong> |
            Kategori: <strong><?php echo e($post->category->name ?? '-'); ?></strong> |
            Status: <span class="badge bg-<?php echo e($post->status == 'published' ? 'success' : 'secondary'); ?>">
                <?php echo e($post->status); ?>

            </span>
        </div>

        <div class="mb-3">
            <strong>Deskripsi:</strong><br>
            <div class="text-secondary"><?php echo e($post->description); ?></div>
        </div>

        <?php
            $cover = $post->images->where('type', 'cover')->first();
            $internalImages = $post->images->where('type', 'internal');
        ?>

        <?php if($cover): ?>
            <div class="mb-3">
                <img src="<?php echo e($cover->url); ?>" alt="Cover Image" class="img-fluid rounded shadow-sm"
                    style="max-height: 300px; object-fit: cover;">
            </div>
        <?php endif; ?>

        <div class="mb-3">
            <strong>Konten:</strong>
            <div class="border rounded p-2 bg-light small">
                <?php echo nl2br(e($post->content)); ?>

            </div>
        </div>

        <?php if($internalImages->count()): ?>
            <div class="mb-3">
                <strong>Gambar Tambahan:</strong>
                <div class="row g-2">
                    <?php $__currentLoopData = $internalImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-6 col-md-4">
                            <img src="<?php echo e($img->url); ?>" alt="Image" class="img-fluid rounded border shadow-sm"
                                style="max-height: 150px; object-fit: cover;">
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        <?php endif; ?>

        <div class="mb-3">
            <strong>Tag:</strong>
            <?php $__currentLoopData = $post->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <span class="badge bg-info text-dark"><?php echo e($tag->name); ?></span>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <div class="mb-3">
            <strong>Teknologi:</strong>
            <?php $__currentLoopData = $post->technologies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tech): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <span class="badge bg-warning text-dark"><?php echo e($tech->name); ?></span>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php if($post->url_download): ?>
            <a href="<?php echo e($post->url_download); ?>" class="btn btn-sm btn-success" target="_blank">Download</a>
        <?php endif; ?>


        <div class="mt-3 d-flex gap-2">
            <a href="<?php echo e(route('posts.edit', $post->id)); ?>" class="btn btn-sm btn-warning">Edit</a>
            <a href="<?php echo e(route('posts.index')); ?>" class="btn btn-sm btn-secondary">Kembali</a>
        </div>

        <hr>
        <h5 class="mt-4">Komentar</h5>

        <?php $__empty_1 = true; $__currentLoopData = $post->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="mb-3 p-2 border rounded bg-white small">
                <div><strong><?php echo e($comment->user->name ?? 'Anonim'); ?></strong>
                    <small class="text-muted"><?php echo e($comment->created_at->diffForHumans()); ?></small>
                </div>
                <div class="text-secondary"><?php echo e($comment->content); ?></div>

                <?php if($comment->replies->count()): ?>
                    <div class="mt-2 ms-3 ps-2 border-start">
                        <?php $__currentLoopData = $comment->replies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reply): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="mb-1">
                                <strong><?php echo e($reply->user->name ?? 'Anonim'); ?></strong>: <?php echo e($reply->content); ?><br>
                                <small class="text-muted"><?php echo e($reply->created_at->diffForHumans()); ?></small>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php endif; ?>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p class="text-muted">Belum ada komentar.</p>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.appmaster', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH P:\laravel12\websourcecode\resources\views/posts/show.blade.php ENDPATH**/ ?>