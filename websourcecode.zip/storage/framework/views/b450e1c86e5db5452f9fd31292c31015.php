

<?php $__env->startSection('content'); ?>
    <div class="text-center py-3">
        <img src="https://assets.dochipo.com/editor/animations/404-error/b6463d8b-ac87-42a7-ad59-6584a19a77a8.gif"
            alt="" width="50%">
        <p class="lead">Halaman yang Anda cari tidak ditemukan.</p>
        <a href="<?php echo e(route('home')); ?>" class="btn btn-primary">
            <i class="fas fa-home me-1"></i> Kembali ke Beranda
        </a>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app_public', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH P:\laravel12\websourcecode\resources\views/errors/404.blade.php ENDPATH**/ ?>