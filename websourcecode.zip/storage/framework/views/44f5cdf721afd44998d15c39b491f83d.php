<div class="mb-3">
    <label>Judul</label>
    <input type="text" name="title" value="<?php echo e(old('title', $post->title ?? '')); ?>" class="form-control" required>
</div>

<div class="mb-3">
    <label>Deskripsi</label>
    <textarea name="description" class="form-control"><?php echo e(old('description', $post->description ?? '')); ?></textarea>
</div>

<div class="mb-3">
    <label>Konten</label>
    <textarea name="content" class="form-control" rows="6"><?php echo e(old('content', $post->content ?? '')); ?></textarea>
</div>
<div class="mb-3">
    <label>URL Download (opsional)</label>
    <input type="url" name="url_download" value="<?php echo e(old('url_download', $post->url_download ?? '')); ?>"
        class="form-control" placeholder="https://contoh.com/file.zip">
</div>

<div class="mb-3">
    <label>Kategori</label>
    <select name="category_id" class="form-select">
        <option value="">-- Pilih Kategori --</option>
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($cat->id); ?>"
                <?php echo e(old('category_id', $post->category_id ?? '') == $cat->id ? 'selected' : ''); ?>><?php echo e($cat->name); ?>

            </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>

<div class="mb-3">
    <label>Status</label>
    <select name="status" class="form-select">
        <option value="draft" <?php echo e(old('status', $post->status ?? '') == 'draft' ? 'selected' : ''); ?>>Draft</option>
        <option value="published" <?php echo e(old('status', $post->status ?? '') == 'published' ? 'selected' : ''); ?>>Published
        </option>
    </select>
</div>

<div class="mb-3">
    <label>Tag</label>
    <select name="tags[]" class="form-select" multiple>
        <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($tag->id); ?>" <?php if(isset($post) && $post->tags->pluck('id')->contains($tag->id)): ?> selected <?php endif; ?>><?php echo e($tag->name); ?>

            </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>

<div class="mb-3">
    <label>Teknologi</label>
    <select name="technologies[]" class="form-select" multiple>
        <?php $__currentLoopData = $technologies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tech): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($tech->id); ?>" <?php if(isset($post) && $post->technologies->pluck('id')->contains($tech->id)): ?> selected <?php endif; ?>><?php echo e($tech->name); ?>

            </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>

<div class="mb-3">
    <label>Gambar Cover</label>
    <input type="file" name="cover" class="form-control">
</div>

<div class="mb-3">
    <label>Gambar Internal (bisa lebih dari satu)</label>
    <input type="file" name="internal_images[]" multiple class="form-control">
</div>

<button class="btn btn-primary"><?php echo e($submit); ?></button>
<a href="<?php echo e(route('posts.index')); ?>" class="btn btn-secondary">Kembali</a>
<?php /**PATH P:\laravel12\websourcecode\resources\views/posts/_form.blade.php ENDPATH**/ ?>