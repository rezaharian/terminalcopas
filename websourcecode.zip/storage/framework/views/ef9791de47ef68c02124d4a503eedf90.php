

<?php $__env->startSection('content'); ?>
    <div class="container py-4">
        
        <?php echo $__env->make('public.hero', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <div class="row">
            
            <div class="col-md-8">
                <?php
                    $sections = [
                        'posts_sc' => 'Source Code ',
                        'posts_tutor' => 'Tutorial ',
                        'posts_artikel' => 'Artikel',
                        'posts_tipstriks' => 'Tips & Tricks',
                        'posts_berita' => 'Berita',
                    ];
                ?>

                <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $title): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(isset($$key) && $$key->count()): ?>
                        <div class="py-4 mt-5 border-bottom">
                            <h5 class="fw-bold text-uppercase text-dark"><?php echo e($title); ?></h5>
                        </div>

                        <div class="row g-3">
                            <?php $__currentLoopData = $$key; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo $__env->make('public._card', ['post' => $post], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                        

                        <div class="text-center mt-2">
                            <a href="<?php echo e(route('posts.kategori', \Str::slug(str_replace('Populer', '', $title)))); ?>"
                                class="btn btn-sm btn-outline-secondary rounded-pill px-4">
                                <i class="fas fa-arrow-right me-1"></i> Lihat Semua <?php echo e($title); ?>

                            </a>
                        </div>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            
            
            <?php echo $__env->make('public.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app_public', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH P:\laravel12\websourcecode\resources\views/home.blade.php ENDPATH**/ ?>