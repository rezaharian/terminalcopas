<div class="col-md-4 mt-5">

    
    <div class="card mb-4 shadow-sm border-0" style="background: var(--color-soft);">
        <div class="card-header text-white fs-6 fw-semibold" style="background: var(--color-dark);">
            <i class="fas fa-folder-open me-2"></i> Kategori
        </div>
        <ul class="list-group list-group-flush">
            <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $title): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="list-group-item px-3 py-2" style="background: var(--color-light);">
                    <a href="<?php echo e(route('posts.kategori', \Str::slug(str_replace('Populer', '', $title)))); ?>"
                        class="text-decoration-none fw-medium d-flex align-items-center justify-content-between"
                        style="color: var(--color-text);">
                        <span><i class="fas fa-angle-right me-2 text-muted"></i> <?php echo e($title); ?></span>
                    </a>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>

    
    <div class="card mb-4 shadow-sm border-0" style="background: var(--color-soft);">
        <div class="card-header text-white fs-6 fw-semibold" style="background: var(--color-accent);">
            <i class="fas fa-tags me-2"></i> Tag Populer
        </div>
        <div class="card-body d-flex flex-wrap gap-2">
            <?php $__currentLoopData = \App\Models\Tag::inRandomOrder()->limit(10)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="#" class="badge rounded-pill px-3 py-2 fw-medium"
                    style="background: var(--color-hover); color: var(--color-dark); text-decoration: none;">
                    <?php echo e($tag->name); ?>

                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

    
    <div class="card mb-4 shadow-sm border-0" style="background: var(--color-soft);">
        <div class="card-header text-white fs-6 fw-semibold" style="background: var(--color-dark);">
            <i class="fas fa-clock me-2"></i> Postingan Terbaru
        </div>
        <ul class="list-group list-group-flush">
            <?php $__currentLoopData = \App\Models\Post::latest()->take(10)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $latest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="list-group-item small px-3 py-2" style="background: var(--color-light);">
                    <a href="<?php echo e(route('posts.selengkapnya', [$latest->id, \Str::slug($latest->title)])); ?>"
                        class="text-decoration-none" style="color: var(--color-text);">
                        <i class="fas fa-circle me-2" style="font-size: 6px; color: var(--color-accent);"></i>
                        <?php echo e(\Illuminate\Support\Str::limit($latest->title, 50)); ?>

                    </a>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>

    
    <?php
        $icons = [
            'codeigniter' => 'devicon-codeigniter-plain colored',
            'php' => 'devicon-php-plain colored',
            'html' => 'devicon-html5-plain colored',
            'css' => 'devicon-css3-plain colored',
            'vue' => 'devicon-vuejs-plain colored',
            'vuejs' => 'devicon-vuejs-plain colored',
            'vue.js' => 'devicon-vuejs-plain colored',
            'react' => 'devicon-react-original colored',
            'javascript' => 'devicon-javascript-plain colored',
            'laravel' => 'devicon-laravel-plain colored',
        ];
    ?>

    <div class="card mb-4 shadow-sm border-0" style="background: var(--color-soft);">
        <div class="card-header text-white fs-6 fw-semibold" style="background: var(--color-accent);">
            <i class="fas fa-code me-2"></i> Teknologi Digunakan
        </div>
        <div class="card-body d-flex flex-wrap gap-2">
            <?php $__currentLoopData = \App\Models\Technology::inRandomOrder()->limit(8)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tech): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $key = strtolower(str_replace(['.', ' '], '', $tech->name));
                    $iconClass = $icons[$key] ?? null;
                ?>

                <span class="badge d-flex align-items-center gap-2 px-3 py-2 fw-medium rounded-pill"
                    style="background: white; border: 1px solid var(--color-accent); color: var(--color-dark);">
                    <?php if($iconClass): ?>
                        <i class="<?php echo e($iconClass); ?>" style="font-size: 18px;"></i>
                    <?php else: ?>
                        <i class="fas fa-code"></i>
                    <?php endif; ?>
                    <?php echo e($tech->name); ?>

                </span>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

</div>
<?php /**PATH P:\laravel12\websourcecode\resources\views/public/sidebar.blade.php ENDPATH**/ ?>