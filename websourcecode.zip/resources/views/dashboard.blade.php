@extends('layouts.appmaster')

@section('content')
    <div class="container ">
        <h4>halo selamat datang cuy</h4>
    </div>
@endsection
